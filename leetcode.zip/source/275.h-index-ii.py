#
# [275] H-Index II
#
# https://leetcode.com/problems/h-index-ii
#
# Medium (34.20%)
# Total Accepted:    
# Total Submissions: 
# Testcase Example:  '[]'
#
# 
# Follow up for H-Index: What if the citations array is sorted in ascending
# order? Could you optimize your algorithm?
# 
#
class Solution(object):
    def hIndex(self, citations):
        """
        :type citations: List[int]
        :rtype: int
        """
        
